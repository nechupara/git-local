result = 0
for i in range(101):
    result += i
print(result)