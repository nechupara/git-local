from tkinter import *
from tkinter import ttk

root=Tk()
frame=ttk.Frame()
frame.grid()

frame.label1=Label(text='aaaaaa')
frame.label1.grid()

root.mainloop()