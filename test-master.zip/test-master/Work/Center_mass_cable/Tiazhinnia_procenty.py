tiazh_max = 12.2


sigma_max = 45
sigm_sredn = 30


print(tiazh_max/sigma_max*sigm_sredn)