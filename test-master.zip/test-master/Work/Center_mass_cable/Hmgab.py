opora_A = 28.3
opora_B = 28.3
gabarit = 8.5 + 8.6

fmax = (opora_A + opora_B)/2 - gabarit
print('максимально допустимая стрела = ' + str(fmax))
height_mgab = (opora_A + opora_B)/2 - 2/3*fmax
print('приведенный центр массы для габаритного пролёта = ' + str(round(height_mgab, 2)))