from functions import *

print(interpol_miu1())

