from functions import *

print(P_m)
print(W_om)
print(find_k_L())
print('ln(l_pr) = '+ str(math.log(l_pr)))