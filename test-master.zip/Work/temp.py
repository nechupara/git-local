from tkinter import *

def check(event):
    if event.keysym == '2':
        print('yes')


root = Tk()
root.title('text')
root.geometry('600x500')

entr1=Entry(root,  width=20, bg='yellow')
entr1.pack()

entr1.bind('<KeyRelease>', check)
entr1.bind('<KeyPress>', check)



root.mainloop()



# from tkinter import *
#
# def onclick():
#    pass
#
# root = Tk()
# text = Text(root)
# text.insert(INSERT, "Hello.....")
# text.insert(END, "Bye Bye.....")
# text.pack()
#
# text.tag_add("here", "1.0", "1.4")
# text.tag_add("start", "1.8", "1.13")
# text.tag_config("here", background="yellow", foreground="blue")
# text.tag_config("start", background="black", foreground="green")
# root.mainloop()